import React from 'react';
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import Login from './Login';
import Register from './Register';
import Cms from "./Cms";


const App = () => {
    if(sessionStorage.getItem('loggedIn')){
        return (
            <Router>
                <Route path="/transactions" exact component={Cms} />
                <Redirect to="/transactions" />
            </Router>
        )
    } else {
        return (
            <Router>
                <Route path="/" exact component={Login} />
                <Route path="/login" exact component={Login} />
                <Route path="/register" component={Register} />
                <Redirect to="/" />
            </Router>
        )
    }

};

export default App;
