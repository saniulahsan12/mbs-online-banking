import React from 'react';
import { Helmet } from 'react-helmet';
import Page from './Page';
import { Card } from 'semantic-ui-react';
import moment from 'moment';

class Deposit extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
        accountInfo: JSON.parse(sessionStorage.getItem('loggedIn'))
    };
  }
  render() {
    return (
      <Page title="">
        <Helmet>
          <title>MBS | Account Info</title>
        </Helmet>
        <Card
          image='https://react.semantic-ui.com/images/avatar/large/elliot.jpg'
          header={this.state.accountInfo.fullName}
          meta={this.state.accountInfo.email}
          description={this.state.accountInfo.personalCode}
          extra={<p>Member Since: {moment(this.state.accountInfo.created_at).format("MMM Do YY")}</p>}
        />
      </Page>
    );
  }
}

export default Deposit;
