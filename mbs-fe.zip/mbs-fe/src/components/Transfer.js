import React from 'react';
import axios from 'axios';
import { Helmet } from 'react-helmet';
import Page from './Page';
import styles from "./Login/styles.css";
import {Dimmer, Form, Loader, Message} from "semantic-ui-react";

class Transfer extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
        amount: 0,
        error: false,
        message: '',
        isLoading: false,
        receiver: ''
    };

    this.handleChange = this.handleChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

    onSubmit(e) {
        e.preventDefault();

        const { amount, receiver } = this.state;
        let data = {};
        data.email = JSON.parse(sessionStorage.getItem('loggedIn')).email;
        data._token = JSON.parse(sessionStorage.getItem('loggedIn'))._token;
        data.amount = amount;
        data.sender = data.email;
        data.receiver = receiver;

        if(data.amount < 100){
            this.setState({
                error: true,
                message: "Minimum Deposit Balance is €100"
            });
        } else {

            this.setState({ error: false, isLoading: true });
            data.amount = -data.amount;
            axios({
                method: 'post',
                url: 'http://localhost:3000/transactions/payment',
                data: data
            })
            .then((response) => {
                //handle success
                if(response.data.error){
                    this.setState({
                        error: true,
                        message: response.data.error,
                        isLoading: false
                    });
                } else {
                    this.setState({
                        error: true,
                        isLoading: false,
                        message: "Amount €"+data.amount+" Transferred Successfully",
                        amount: 0,
                        receiver: ''
                    });
                }
            })
            .catch((error) => {
                //handle error
                this.setState({
                    error: true,
                    message: error,
                    isLoading: false
                });
            });
        }
    }

    handleChange(e, { name, value }) {
        this.setState({ [name]: value, message: '' });
    }

  render() {
    return (
      <Page title="Fund Transfer">
        <Helmet>
          <title>MBS | Fund Transfer</title>
        </Helmet>

          <Form className={styles.loginForm} onSubmit={this.onSubmit}>

              {this.state.isLoading &&
              <Dimmer active inverted inline={"true"}>
                  <Loader inverted content='Submitting...' />
              </Dimmer>}
              {this.state.error && <Message
                  error={this.state.error}
                  content={this.state.message}
              />}
              {this.state.message && <Message color='blue'>{this.state.message}</Message>}
              <Form.Input
                  inline
                  placeholder="Place Amount"
                  type="number"
                  name="amount"
                  width="eight"
                  value={this.state.amount}
                  onChange={this.handleChange}
              />
              <Form.Input
                  inline
                  placeholder="Place Account Number / Email"
                  type="email"
                  name="receiver"
                  width="eight"
                  value={this.state.receiver}
                  onChange={this.handleChange}
              />
              <Form.Button type="submit">Fund Transfer!</Form.Button>

          </Form>
      </Page>
    );
  }
}

export default Transfer;
