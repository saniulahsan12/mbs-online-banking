import React from 'react';
import {Grid, Form, Header, Message, Dimmer, Loader, Icon} from 'semantic-ui-react';
import { Helmet } from 'react-helmet';
import axios from 'axios';
import styles from './styles.css';
import {Link} from "react-router-dom";

class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      email: '',
      password: '',
      error: false,
      message: '',
      isLoading: false,
    };

    this.handleChange = this.handleChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onSubmit(e) {
    e.preventDefault();

    const { email, password } = this.state;
    let data = {};
    data.email = email;
    data.password = password;

    this.setState({ error: false, isLoading: true });

    axios({
      method: 'post',
      url: 'http://localhost:3000/login',
      data: data
    })
    .then((response) => {
      //handle success
      if(response.data.error){
        this.setState({
          error: true,
          message: response.data.error,
          isLoading: false
        });
      } else {
        this.setState({
          error: false
        });
        sessionStorage.setItem('loggedIn', JSON.stringify(response.data.loggedInUser));
        if(sessionStorage.getItem('loggedIn')){
          window.location.href = '/transactions';
        }
        console.log(JSON.parse(sessionStorage.getItem('loggedIn')));
      }
    })
    .catch((error) => {
      //handle error
      this.setState({
        error: true,
        message: error,
        isLoading: false
      });
    });
  }

  handleChange(e, { name, value }) {
    this.setState({ [name]: value });
  }

  render() {
    const { error, message } = this.state;

    return (
      <Grid>
        <Helmet>
          <title>MBS | Login</title>
        </Helmet>

        <Grid.Column width={6} />
        <Grid.Column width={4}>
          <br/>
          <br/>
          <br/>
          <br/>
          <br/>
          <Form className={styles.loginForm} error={error} onSubmit={this.onSubmit}>

            {this.state.isLoading &&
            <Dimmer active inverted inline={"true"}>
              <Loader inverted content='Submitting...' />
            </Dimmer>}

            <Header as="h1"><Icon name="address card outline" /> Login</Header>
            {error && <Message
              error={error}
              content={message}
            />}
            <Form.Input
              inline
              placeholder="Email"
              name="email"
              width="sixteen"
              onChange={this.handleChange}
            />
            <Form.Input
              inline
              placeholder="Password"
              type="password"
              name="password"
              width="sixteen"
              onChange={this.handleChange}
            />
            <Form.Button type="submit">Go!</Form.Button>

            <Link to="/register">
              Register Now
            </Link>

          </Form>
        </Grid.Column>
      </Grid>
    );
  }
}

export default Login;
