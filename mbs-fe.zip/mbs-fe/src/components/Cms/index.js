/* eslint-disable arrow-body-style */
import React from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import { Sidebar, Menu, Icon, Dimmer, Loader } from 'semantic-ui-react';
import axios from 'axios';
import { Helmet } from 'react-helmet';
import styles from './styles.css';
import Transactions from '../Transactions.js';
import Deposit from '../Deposit.js';
import Transfer from '../Transfer.js';
import Account from '../Account.js';

class Cms extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
        };
        this.handleLogout = this.handleLogout.bind(this);
    }

    handleLogout(){
        this.setState({ error: false, isLoading: true });
        let _token = JSON.parse(sessionStorage.getItem('loggedIn'))._token;
        let data = {};
        data._token = _token;
        axios({
            method: 'post',
            url: 'http://localhost:3000/logout',
            data: data
        })
        .then((response) => {
            this.setState({
                isLoading: false
            });
            sessionStorage.clear();
            window.location.href = '/';
        })
        .catch((error) => {
            alert(error);
            this.setState({
                isLoading: false
            });
        });
    }

    render() {
        return (
            <Router>
                <div>
                    <Helmet>
                        <title>Dashboard</title>
                    </Helmet>

                    {this.state.isLoading &&
                    <Dimmer active inverted inline={"true"}>
                        <Loader inverted content='Logging Out...' />
                    </Dimmer>}

                    <Sidebar as={Menu} inverted visible vertical width="thin" icon="labeled">

                        <Link to="/transactions">
                            <Menu.Item name="transactions">
                                <Icon name="calculator"/>
                                Transactions
                            </Menu.Item>
                        </Link>

                        <Link to="/deposit">
                            <Menu.Item name="deposit">
                                <Icon name="download" />
                                Deposit
                            </Menu.Item>
                        </Link>

                        <Link to="/fund-transfer">
                            <Menu.Item name="fund-transfer">
                                <Icon name="address card outline" />
                                Fund Transfer
                            </Menu.Item>
                        </Link>

                        <Link to="/account-info">
                            <Menu.Item name="account-info">
                                <Icon name="user secret" />
                                Account Info
                            </Menu.Item>
                        </Link>


                        <Menu.Item name="logout" onClick={this.handleLogout}>
                            <Icon name="power"/>
                            Logout
                        </Menu.Item>

                    </Sidebar>
                    <div className={styles.mainBody}>
                        <Route path="/transactions" component={Transactions}/>
                        <Route path="/deposit" component={Deposit} />
                        <Route path="/fund-transfer" component={Transfer} />
                        <Route path="/account-info" component={Account} />
                    </div>
                </div>
            </Router>

        );
    }
};

export default Cms;
