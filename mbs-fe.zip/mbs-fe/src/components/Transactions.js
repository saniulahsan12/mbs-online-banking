import React from 'react';
import {Table, Dimmer, Loader, Message, Menu, Label} from 'semantic-ui-react';
import axios  from 'axios';
import moment  from 'moment';
import { Helmet } from 'react-helmet';
import Page from './Page';

class Transactions extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      transactions: [],
      error: false,
      isLoading: false,
      message: '',
      email: ''
    };
  }

  componentDidMount() {
    this.getTransactions();
  }

  getTransactions() {
    let data = {};
    data.email = JSON.parse(sessionStorage.getItem('loggedIn')).email;
    data._token = JSON.parse(sessionStorage.getItem('loggedIn'))._token;
    this.setState({ error: false, isLoading: true, email: data.email });
    axios({
      method: 'post',
      url: 'http://localhost:3000/transactions/all',
      data: data
    })
    .then((response) => {
      //handle success
      if(response.data.error){
        this.setState({
          error: true,
          message: response.data.error,
          isLoading: false,
          transactions: []
        });
      } else {
        this.setState({
          error: false,
          isLoading: false,
          message: '',
          transactions: response.data.data
        });
      }
    })
    .catch((error) => {
      //handle error
      this.setState({
        error: true,
        message: error,
        isLoading: false
      });
    });
  }

  static getTotalBalance(totalAmount){
    let sum = 0;
    for (let i = 0; i < totalAmount
        .length; i++) {
      sum += totalAmount[i];
    }
    return sum;
  }

  static transactionType(from, to, amount){
    let transactionType = 'UNAUTHORIZED';
    if(from === to && parseFloat(amount) > 0){
      transactionType = <Label color={"green"}>SELF DEPOSIT</Label>;
    }
    if(from !== to && parseFloat(amount) > 0){
      transactionType = <Label color={"blue"}>EXTERNAL DEPOSIT</Label>;
    }
    if(from !== to && parseFloat(amount) < 0){
      transactionType = <Label color={"red"}>BALANCE TRANSFER</Label>;
    }

    return transactionType;
  }

  render() {
    let totalAmount = [];
    return (
      <Page title="Transactions & Balance">
        <Helmet>
          <title>MBS | Transactions</title>
        </Helmet>

        {this.state.isLoading &&
        <Dimmer active inverted inline={"true"}>
          <Loader inverted content='Submitting...' />
        </Dimmer>}

        {this.state.error && <Message
            error={this.state.error}
            content={this.state.message}
        />}

        <Table celled padded>
          <Table.Header  colSpan='3'>
            <Table.Row>
              <Table.HeaderCell textAlign='left'>Transaction ID</Table.HeaderCell>
              <Table.HeaderCell textAlign='left'>Sender</Table.HeaderCell>
              <Table.HeaderCell textAlign='left'>Receiver</Table.HeaderCell>
              <Table.HeaderCell textAlign='center'>Transaction Type</Table.HeaderCell>
              <Table.HeaderCell textAlign='right'>Date</Table.HeaderCell>
              <Table.HeaderCell textAlign='right'>Amount</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {
              this.state.transactions.map((transaction) =>
                  <Table.Row key={transaction._id}>
                      <Table.Cell>{transaction.tnxId}</Table.Cell>
                      <Table.Cell>{transaction.from}</Table.Cell>
                      <Table.Cell>{transaction.to}</Table.Cell>
                      <Table.Cell>
                          { (this.state.email === transaction.to) ?
                              Transactions.transactionType(transaction.from, transaction.to, Math.abs(parseFloat(transaction.amount))) :
                              Transactions.transactionType(transaction.from, transaction.to, parseFloat(transaction.amount))
                          }
                      </Table.Cell>
                    <Table.Cell textAlign='center'>{moment(transaction.created_at).format('MMMM Do YYYY, h:mm:ss a')}</Table.Cell>
                    <Table.Cell textAlign='right'>€
                        {
                        (this.state.email === transaction.to) ?
                            Math.abs(parseFloat(transaction.amount)) :
                            parseFloat(transaction.amount)
                        }
                    </Table.Cell>
              </Table.Row>
              )
            }
          </Table.Body>
          <Table.Footer>
            <Table.Row>
              <Table.HeaderCell colSpan='6'>
                <Menu floated='right'>
                  <Menu.Item>
                    <h3>Account Balance: </h3>
                  </Menu.Item>
                  <Menu.Item>
                    <h3>
                      {
                        this.state.transactions.map((transaction) => {
                            if(this.state.email === transaction.to){
                              totalAmount.push( Math.abs(parseFloat(transaction.amount)) );
                            } else {
                              totalAmount.push(parseFloat(transaction.amount));
                            }
                        })
                      }
                      {
                        '€' + Transactions.getTotalBalance(totalAmount)
                      }
                    </h3>
                  </Menu.Item>
                </Menu>
              </Table.HeaderCell>
            </Table.Row>
          </Table.Footer>
        </Table>
      </Page>
    );
  }
}

export default Transactions;
