import React from 'react';
import {Grid, Form, Header, Message, Dimmer, Loader, Icon} from 'semantic-ui-react';
import { Helmet } from 'react-helmet';
import axios from 'axios';
import styles from './styles.css';
import {Link} from "react-router-dom";

class Register extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      email: '',
      password: '',
      error: false,
      message: '',
      isLoading: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onSubmit(e) {
    e.preventDefault();

    const { fullName, email, password, personalCode } = this.state;
    let data = {};
    data.fullName = fullName;
    data.email = email;
    data.password = password;
    data.personalCode = personalCode;

    this.setState({ error: false, isLoading: true });

    axios({
      method: 'post',
      url: 'http://localhost:3000/add-or-update-user',
      data: data
    })
    .then((response) => {
      //handle success
      if(response.data.message){
        this.setState({
          error: true,
          message: response.data.message,
          isLoading: false
        });
      } else {
        this.setState({
          error: false
        });
        alert('Registration Successful. Please Login');
        window.location.href = '/login';
      }
    })
    .catch((error) => {
      //handle error
      this.setState({
        error: true,
        message:error,
        isLoading: false
      });
    });
  }

  handleChange(e, { name, value }) {
    this.setState({ [name]: value });
  }

  render() {
    const { error, message } = this.state;

    return (
      <Grid>
        <Helmet>
          <title>MBS | Register Now</title>
        </Helmet>

        <Grid.Column width={6} />
        <Grid.Column width={4}>
          <br/>
          <br/>
          <br/>
          <br/>
          <br/>
          <Form className={styles.loginForm} error={error} onSubmit={this.onSubmit}>

            {this.state.isLoading &&
            <Dimmer active inverted inline>
              <Loader inverted content='Submitting...' />
            </Dimmer>}

            <Header as="h1"><Icon name="user secret" /> Register Now</Header>
            {error && <Message
              error={error}
              content={message}
            />}
            <Form.Input
                inline
                placeholder="Full Name"
                name="fullName"
                width="sixteen"
                onChange={this.handleChange}
            />
            <Form.Input
              inline
              placeholder="Email"
              name="email"
              width="sixteen"
              onChange={this.handleChange}
            />
            <Form.Input
              inline
              placeholder="Password"
              type="password"
              name="password"
              width="sixteen"
              onChange={this.handleChange}
            />
            <Form.Input
                inline
                placeholder="Personal Code"
                name="personalCode"
                width="sixteen"
                onChange={this.handleChange}
            />
            <Form.Button type="submit">Register Now!</Form.Button>

            <Link to="/login">
              Login Now
            </Link>

          </Form>
        </Grid.Column>
      </Grid>
    );
  }
}

export default Register;
