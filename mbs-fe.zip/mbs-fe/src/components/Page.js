import React from 'react';
import { Grid, Header, Container } from 'semantic-ui-react';

const Page = ({ children, title, columns = 1 }) =>
  (<div>
    <Grid columns={columns} padded>
      <Grid.Column>
          <Container>
            {title && <Header as="h1" floated="left">{title}</Header>}
            {children}
          </Container>
      </Grid.Column>
    </Grid>
  </div>);

export default Page;
